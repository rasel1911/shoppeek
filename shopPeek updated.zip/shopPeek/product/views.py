from django.shortcuts import render
# Create your views here.
def shop_details(request):
    return render(request, 'shop-details.html')

def shop_grid(request):
    return render(request, 'shop-grid.html')