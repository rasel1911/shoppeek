from .views import shop_details,shop_grid
from django.urls import path


urlpatterns = [
    path('shopdetails/', shop_details, name='shopdetails'),
    path('shopgrid/',shop_grid, name="shopgrid"),
]