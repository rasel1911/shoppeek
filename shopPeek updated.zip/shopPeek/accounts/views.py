# accounts/views.py
#from django.shortcuts import render, redirect, HttpResponse
#from django.contrib.auth import login, logout, authenticate
#from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
#from django.db import connection
#from .models import User
#from .forms import LoginForm
#from django.contrib import messages

from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import LoginForm


"""
users=User.objects.all()
for user in users:
    print(user.name, user.password)
"""
def home_views(request):
    return render(request, 'home.html')



"""
def register(request):
    if request.method == 'POST':
        name = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password1")
        my_user=User(name=name,email=email,password=password)
        my_user.save()
    return render(request, 'signup.html')

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            
            try:
                user = User.objects.get(email=email)
                if user.password == password:  # Use Django authentication for security
                    request.session['user_id'] = user.id  # Store session manually
                    messages.success(request, "Login successful")
                    print(user.name)
                    return redirect('home')  # Redirect to home or dashboard
                else:
                    messages.error(request, "password invalid!!")
            except User.DoesNotExist:
                messages.error(request, "User not found")
    else:
        form = LoginForm()
    
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('login')
"""

def register(request):
    if request.method == 'POST':
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password1")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            user.save()
            messages.success(request, "Account created successfully!")
            return redirect('login')  # Redirect to login page

    return render(request, 'signup.html')


def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            # Authenticate user
            user = authenticate(username=username, password=password)
            print(user)
            if user is not None:
                login(request, user)  # Django's built-in login
                messages.success(request, "Login successful")
                return redirect('home')  # Redirect to home or dashboard
            else:
                messages.error(request, "Invalid email or password")
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out successfully!")
    return redirect('home')



def Contact(request):
    return render(request, 'contact.html')

