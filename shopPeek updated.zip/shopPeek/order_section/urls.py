from .views import shopping_card,Checkout
from django.urls import path


urlpatterns = [
    path('shoppingcard/',shopping_card, name="shoppingcard"),
    path('checkout/',Checkout, name="checkout"),
]