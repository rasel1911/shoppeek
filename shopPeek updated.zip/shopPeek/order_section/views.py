from django.shortcuts import render

# Create your views here.
def shopping_card(request):
    return render(request, 'shoping-cart.html')

def Checkout(request):
    return render(request, 'checkout.html')