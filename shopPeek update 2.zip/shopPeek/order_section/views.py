from django.shortcuts import get_object_or_404, render, redirect
from django.http import JsonResponse
from .models import Card
from product.models import Product_varient
from accounts.models import User_data
from django.contrib.auth.decorators import login_required


@login_required
def add_to_cart(request):
    #customar_id = User_data.objects.get(id=1)
    if request.method == "POST":
        user = request.user
        product_id = request.POST.get("product_id")
        product = get_object_or_404(Product_varient, id=product_id)
        session_id = request.session.session_key
        print(product.title_pv)
        if not session_id:
            request.session.create()
            session_id = request.session.session_key

        cart_item, created = Card.objects.get_or_create(
            customar_id=user,
            product_varient_id=product,
            defaults={"quantity": 1}
        )

        if not created:
            cart_item.quantity += 1
            cart_item.save()

        # Redirect back to the same page
        return redirect(request.META.get('HTTP_REFERER', '/'))

    return JsonResponse({"error": "Invalid request"}, status=400)
        




# Create your views here.
@login_required
def shopping_card(request):
    user = request.user
    cart_items = Card.objects.filter(customar_id=user)
        
    return render(request, 'shoping-cart.html',{"cart_items":cart_items})

def Checkout(request):
    return render(request, 'checkout.html')

def update_cart(request):
    pass
def remove_from_cart(request):
    if request.method == "POST":
        item_id = request.POST.get('item_id')
        try:
            cart_item = Card.objects.get(id=item_id, customar_id=request.user)
            cart_item.delete()
            return redirect(request.META.get('HTTP_REFERER', '/'))
        
        except Card.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Item not found'}, status=404)
        