from django.shortcuts import render

# Create your views here.


def Blog_details(request):
    return render(request,"blog-details.html")

def Blog(request):
    return render(request, "blog.html")