from django.apps import AppConfig


class OrderSectionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "order_section"
