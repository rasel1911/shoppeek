# accounts/views.py
from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.db import connection
from .models import User
from .forms import LoginForm
from django.contrib import messages
"""
users=User.objects.all()
for user in users:
    print(user.name, user.password)
"""
def home_views(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        name = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password1")
        my_user=User(name=name,email=email,password=password)
        my_user.save()
    return render(request, 'signup.html')

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            
            try:
                user = User.objects.get(email=email)
                if user.password == password:  # Use Django authentication for security
                    request.session['user_id'] = user.id  # Store session manually
                    messages.success(request, "Login successful")
                    return redirect('home')  # Redirect to home or dashboard
                else:
                    messages.error(request, "password invalid!!")
            except User.DoesNotExist:
                messages.error(request, "User not found")
    else:
        form = LoginForm()
    
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('login')
