from django.urls import path
from .views import register, user_login, user_logout, home_views
from django.urls import include, path
urlpatterns = [
    
    path('', home_views, name='home'),
    
    path('register/', register, name='register'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
]
